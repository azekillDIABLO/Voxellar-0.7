V8

hook:
hit on a edge to climb up.

upgraded hook:
use with double hight

rope:
place on a edge to climb, or throw it.

locked rope:
only you can take it, or throw it.

slingshot:
throw junk far away and hurt your enemies
place it to change side to use

Mouth breather assembly:
use outside water/vaccum to refill with air, use in water/vaccum to refill your breath (max 10 times))

V8:
Added: new models
Fixed: a lot of bug & glitchs
Added: Mouth breather assembly
Added: possable to throw ropes