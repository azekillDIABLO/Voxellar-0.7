# myholeinthewall

Create garden wall type blocks in minetest.

You need to build a drill press first. 
Place the drill press and right click on the top part.
Put nodes inside and click on the style of block you want.
There are full nodes and half nodes.
Right click on the bottom of the drill press for storage.

Licence - WTFPL

Forum - https://forum.minetest.net/viewtopic.php?f=9&t=14209
