myholeinthewall = {}
dofile(minetest.get_modpath("myholeinthewall").."/nodes.lua")
dofile(minetest.get_modpath("myholeinthewall").."/machine.lua")
dofile(minetest.get_modpath("myholeinthewall").."/register.lua")








