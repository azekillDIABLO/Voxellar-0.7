## Crafting Guide ##

##### A simple and fast Crafting Guide that doesn't suck for Minetest.

##### Usable with a book named *"Crafting Guide"*. #####

##### This mod is originating from [X-Decor](https://github.com/kilbith/xdecor). #####

![Preview](http://i.imgur.com/xblp1Vs.png)

