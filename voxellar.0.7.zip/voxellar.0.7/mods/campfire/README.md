CampFire mod by Doc

[modified by Napiophelios-rev014]

Depends: default, fire,  wool

For Minetest 0.4.10 development build (commit d2219171 or later)

Original CampFire mod by Doc
License of code : WTFPL

https://github.com/Doc22/campfire-mod


Node Swap ABM from NateS's More_fire mod

(solves the glitchy formspec transition)

More_fire mod
Licensed : CC by SA

https://github.com/NathanSalapat/more_fire


The smoke particles from LazyJ's Fork of Semmett9's "Fake Fire" Mod

code by: VanessaE and JP

License:  GPL v2
