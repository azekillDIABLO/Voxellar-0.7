-- Play time of the longest song in the list in seconds( suggest adding maybe 10 seconds to be safe )
longest = 395
-- amount of time to wait after server starts up to begin playing in seconds
delay = 20
-- volume or gain or level to play the music ( default was set for sample music )
playvol = .5
