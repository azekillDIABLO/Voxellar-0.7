# TNT Extras
This mod adds extra TNT blast effects. It changes stone like nodes into gravel or rarely into lava source blocks, sand-like blocks into glass fragments and makes obsidian, obsidian brick, mese,nyancats and nyancat rainbows and diamond blocks resistant to TNT (they will still get damaged but only rarely)

# Licence
This mod is released under WTFPL.
