Mysponge

Soak up water with this sponge.

Put the wet sponge in the furnace and get water.

Leave the sponge sit out and it will dry.


Licence - WTFPL
