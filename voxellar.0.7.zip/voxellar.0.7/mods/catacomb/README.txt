catacomb 0.4.0 by paramat
For Minetest 0.4.8 and later
Depends default
Licenses: code WTFPL
