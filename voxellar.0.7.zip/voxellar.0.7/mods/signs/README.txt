=== SIGNS-MOD for MINETEST-C55===
by xyz
modified by PilzAdam

Introduction:
This mod adds signs to Minetest, wich you can read without pointing at
the sign. The text is integrated into the 3D world.

How to install:
Unzip the archive an place it in minetest-base-directory/mods/minetest/
if you have a windows client or a linux run-in-place client. If you have
a linux system-wide instalation place it in ~/.minetest/mods/minetest/.
If you want to install this mod only in one world create the folder
worldmods/ in your worlddirectory.
For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods

How to use the mod:
Craft a sign like the default signs and place them. Rightclick it and enter
your text. You can use " | " to create a newline. Hitting enter or
clicking proceed will save the text and add it to the sign.
If the text of a sign disapears just rightclick it and hit enter again.

License:
Sourcecode: WTFPL (see below)
Font: 04b-03 (http://04.jp.org/)

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 
