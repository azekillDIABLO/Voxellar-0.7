=== SPEARS for MINETEST ===

This mod adds spears to Minetest. It aims at improving the ones introduced within throwing enhanced.

How to install:
http://wiki.minetest.com/wiki/Installing_Mods

How to use the mod:
Spear work similarly to other tools such as swords, even if being a little slower. Moreover, a spear can be thrown using the drop key ('Q') or placed on a node using the place key ('right click'); they have also limited digging capabilities.

License:
Sourcecode: LGPLv2.1 (see http://www.gnu.org/licenses/lgpl-2.1.html)
Grahpics & sounds: CC-BY 3.0 (see http://creativecommons.org/licenses/by/3.0/legalcode)