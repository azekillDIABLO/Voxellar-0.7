
This mod is not finished yet.

Create a file named
	list_of_schematics.txt
in the folder containing this mod (not the world!).
Each line of the file ought to contain the name and full path to a schematic.
Those will be offered to you in the build chest's menu under "main".

Type "/giveme handle_schematics:build" to get a build chest.
